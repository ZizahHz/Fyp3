import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cust-profile',
  templateUrl: './cust-profile.page.html',
  styleUrls: ['./cust-profile.page.scss'],
})
export class CustProfilePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
