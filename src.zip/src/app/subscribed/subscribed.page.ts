import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-subscribed',
  templateUrl: './subscribed.page.html',
  styleUrls: ['./subscribed.page.scss'],
})
export class SubscribedPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
