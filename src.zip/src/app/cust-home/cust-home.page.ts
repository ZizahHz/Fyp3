import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cust-home',
  templateUrl: './cust-home.page.html',
  styleUrls: ['./cust-home.page.scss'],
})
export class CustHomePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
