export const environment = {
  firebase: {
    projectId: 'beautycare-2fd4f',
    appId: '1:135520417062:web:0626ca22d3521ed5aa7de7',
    databaseURL: 'https://beautycare-2fd4f-default-rtdb.asia-southeast1.firebasedatabase.app',
    storageBucket: 'beautycare-2fd4f.appspot.com',
    locationId: 'us-central',
    apiKey: 'AIzaSyC63PC3yES4VTHCYcHn3c2EttZgJ4muvG8',
    authDomain: 'beautycare-2fd4f.firebaseapp.com',
    messagingSenderId: '135520417062',
    measurementId: 'G-T0BL3YPYBQ',
  },
  production: true
};
